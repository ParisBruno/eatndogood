/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","hu",{title:"Helytart\xf3 be\xe1ll\xedt\xe1sok",toolbar:"Helytart\xf3 k\xe9sz\xedt\xe9se",name:"Helytart\xf3 neve",invalidName:"A helytart\xf3 nem lehet \xfcres, \xe9s nem tartalmazhatja a k\xf6vetkez\u0151 karaktereket:[, ], <, > ",pathName:"helytart\xf3"});