/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","es-mx",{title:"Propiedades del marcador de posici\xf3n",toolbar:"Marcador de posici\xf3n",name:"Nombre del marcador de posici\xf3n",invalidName:"El marcador de posici\xf3n no puede estar vac\xedo y no puede contener alguno de los siguientes caracteres: [, ], <, >",pathName:"marcador de posici\xf3n"});