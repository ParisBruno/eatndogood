/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","sr-latn",{title:"Pode\u0161avanje rezervnog mesta",toolbar:"Pripremanje rezervnog mesta",name:"Naziv rezervnog mesta",invalidName:"Rezervno  mesto ne mo\u017ee biti prazno, ne mo\u017ee da sadr\u017ei slede\u0107e karaktere:  [, ], <, >",pathName:"Rezervno mesto"});