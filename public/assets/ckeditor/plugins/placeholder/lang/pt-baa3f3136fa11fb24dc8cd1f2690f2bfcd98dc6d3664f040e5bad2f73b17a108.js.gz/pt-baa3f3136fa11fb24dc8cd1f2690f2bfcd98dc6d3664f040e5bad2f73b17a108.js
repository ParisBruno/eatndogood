/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","pt",{title:"Propriedades dos marcadores",toolbar:"Marcador",name:"Nome do marcador",invalidName:"O marcador n\xe3o pode estar em branco e n\xe3o pode conter qualquer dos seguintes carateres: [, ], <, >",pathName:"marcador"});