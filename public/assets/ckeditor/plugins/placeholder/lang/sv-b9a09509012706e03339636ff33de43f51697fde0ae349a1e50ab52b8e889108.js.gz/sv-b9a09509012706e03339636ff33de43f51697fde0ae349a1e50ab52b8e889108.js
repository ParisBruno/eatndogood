/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","sv",{title:"Inneh\xe5llsrutans egenskaper",toolbar:"Skapa inneh\xe5llsruta",name:"Inneh\xe5llsrutans namn",invalidName:"Inneh\xe5llsrutan f\xe5r inte vara tom och f\xe5r inte inneh\xe5lla n\xe5gon av f\xf6ljande tecken: [, ], <, >",pathName:"inneh\xe5llsruta"});