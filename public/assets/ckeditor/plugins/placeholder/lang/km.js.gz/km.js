/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","km",{title:"\u179b\u1780\u17d2\u1781\u178e\u17c8 Placeholder",toolbar:"\u1794\u1784\u17d2\u1780\u17be\u178f Placeholder",name:"\u1788\u17d2\u1798\u17c4\u17c7 Placeholder",invalidName:"Placeholder \u1798\u17b7\u1793\u200b\u17a2\u17b6\u1785\u200b\u1791\u1791\u17c1\u179a \u17a0\u17be\u1799\u1780\u17cf\u200b\u1798\u17b7\u1793\u200b\u17a2\u17b6\u1785\u200b\u1798\u17b6\u1793\u200b\u178f\u17bd\u200b\u17a2\u1780\u17d2\u179f\u179a\u200b\u1791\u17b6\u17c6\u1784\u200b\u1793\u17c1\u17c7\u200b\u1791\u17c1\u17d6 [, ], <, >",pathName:"placeholder"});