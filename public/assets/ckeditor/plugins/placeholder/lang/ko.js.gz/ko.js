/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","ko",{title:"\ud50c\ub808\uc774\uc2a4\ud640\ub354 \uc18d\uc131",toolbar:"\ud50c\ub808\uc774\uc2a4\ud640\ub354",name:"\ud50c\ub808\uc774\uc2a4\ud640\ub354 \uc774\ub984",invalidName:"\ud50c\ub808\uc774\uc2a4\ud640\ub354\ub294 \ube48\uce78\uc774\uac70\ub098 \ub2e4\uc74c \ubb38\uc790\uc5f4\uc744 \ud3ec\ud568\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4: [, ], <, >",pathName:"\ud50c\ub808\uc774\uc2a4\ud640\ub354"});