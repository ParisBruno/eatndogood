/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","az",{title:"Yertutan\u0131n x\xfcsusiyy\u0259tl\u0259ri",toolbar:"Yertutan",name:"Yertutan\u0131n ad\u0131",invalidName:"Yertutan bo\u015f ola bilm\u0259z, h\u0259m d\u0259 [, ], <, > i\u015far\u0259l\u0259rd\u0259n ehtiva ed\u0259 bilm\u0259z",pathName:"yertutan"});