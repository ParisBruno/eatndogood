/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","si",{title:"\u0dc3\u0dca\u0dae\u0dcf\u0db1 \u0dc4\u0dd3\u0db8\u0dca\u0d9a\u0dbb\u0dd4\u0d9c\u0dda ",toolbar:"\u0dc3\u0dca\u0dae\u0dcf\u0db1 \u0dc4\u0dd3\u0db8\u0dca\u0d9a\u0dbb\u0dd4 \u0db1\u0dd2\u0dbb\u0dca\u0db8\u0dcf\u0dab\u0dba \u0d9a\u0dd2\u0dbb\u0dd3\u0db8",name:"Placeholder Name",invalidName:"The placeholder can not be empty and can not contain any of following characters: [, ], <, >",pathName:"placeholder"});