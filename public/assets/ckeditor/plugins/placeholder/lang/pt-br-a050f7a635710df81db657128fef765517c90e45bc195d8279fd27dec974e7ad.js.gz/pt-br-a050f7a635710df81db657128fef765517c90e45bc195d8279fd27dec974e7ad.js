/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","pt-br",{title:"Propriedades do Espa\xe7o Reservado",toolbar:"Criar Espa\xe7o Reservado",name:"Nome do Espa\xe7o Reservado",invalidName:"O espa\xe7o reservado n\xe3o pode estar vazio e n\xe3o pode conter nenhum dos seguintes caracteres:  [, ], <, >",pathName:"Espa\xe7o Reservado"});