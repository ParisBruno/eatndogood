/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","sk",{title:"Vlastnosti placeholdera",toolbar:"Vytvori\u0165 placeholder",name:"N\xe1zov placeholdera",invalidName:"Placeholder nem\xf4\u017ee by\u0165 pr\xe1zdny a nem\xf4\u017ee obsahova\u0165 \u017eiadny z nasleduj\xfacich znakov: [,],<,>",pathName:"placeholder"});