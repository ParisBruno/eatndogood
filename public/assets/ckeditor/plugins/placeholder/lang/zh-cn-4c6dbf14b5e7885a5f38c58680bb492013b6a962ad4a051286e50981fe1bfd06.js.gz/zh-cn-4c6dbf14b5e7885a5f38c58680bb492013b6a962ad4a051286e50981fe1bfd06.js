/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","zh-cn",{title:"\u5360\u4f4d\u7b26\u5c5e\u6027",toolbar:"\u5360\u4f4d\u7b26",name:"\u5360\u4f4d\u7b26\u540d\u79f0",invalidName:"\u5360\u4f4d\u7b26\u540d\u79f0\u4e0d\u80fd\u4e3a\u7a7a\uff0c\u5e76\u4e14\u4e0d\u80fd\u5305\u542b\u4ee5\u4e0b\u5b57\u7b26\uff1a[\u3001]\u3001<\u3001>",pathName:"\u5360\u4f4d\u7b26"});