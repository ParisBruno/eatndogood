/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","gl",{title:"Propiedades do marcador de posici\xf3n",toolbar:"Crear un marcador de posici\xf3n",name:"Nome do marcador de posici\xf3n",invalidName:"O marcador de posici\xf3n non pode estar baleiro e non pode conter ning\xfan dos caracteres seguintes: [, ], <, >",pathName:"marcador de posici\xf3n"});