/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang("placeholder","fi",{title:"Paikkamerkin ominaisuudet",toolbar:"Luo paikkamerkki",name:"Paikkamerkin nimi",invalidName:"Paikkamerkki ei voi olla tyhj\xe4 eik\xe4 sis\xe4lt\xe4\xe4 seuraavia merkkej\xe4: [, ], <, >",pathName:"paikkamerkki"});