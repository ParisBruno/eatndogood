/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/

CKEDITOR.plugins.setLang( 'templates', 'hi', {
	button: 'टॅम्प्लेट',
	emptyListMsg: '(कोई टॅम्प्लेट डिफ़ाइन नहीं किया गया है)',
	insertOption: 'मूल शब्दों को बदलें',
	options: 'Template Options', // MISSING
	selectPromptMsg: 'ऍडिटर में ओपन करने हेतु टॅम्प्लेट चुनें(वर्तमान कन्टॅन्ट सेव नहीं होंगे):',
	title: 'कन्टेन्ट टॅम्प्लेट'
} );
