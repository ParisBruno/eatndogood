/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","bg",{fontSize:{label:"\u0420\u0430\u0437\u043c\u0435\u0440",voiceLabel:"\u0420\u0430\u0437\u043c\u0435\u0440 \u043d\u0430 \u0448\u0440\u0438\u0444\u0442",panelTitle:"\u0420\u0430\u0437\u043c\u0435\u0440 \u043d\u0430 \u0448\u0440\u0438\u0444\u0442"},label:"\u0428\u0440\u0438\u0444\u0442",panelTitle:"\u0418\u043c\u0435 \u043d\u0430 \u0448\u0440\u0438\u0444\u0442",voiceLabel:"\u0428\u0440\u0438\u0444\u0442"});