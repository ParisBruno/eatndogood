/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","mn",{fontSize:{label:"\u0425\u044d\u043c\u0436\u044d\u044d",voiceLabel:"\u04ae\u0441\u0433\u0438\u0439\u043d \u0445\u044d\u043c\u0436\u044d\u044d",panelTitle:"\u04ae\u0441\u0433\u0438\u0439\u043d \u0445\u044d\u043c\u0436\u044d\u044d"},label:"\u04ae\u0441\u0433\u0438\u0439\u043d \u0445\u044d\u043b\u0431\u044d\u0440",panelTitle:"\u04ae\u0433\u0441\u0438\u0439\u043d \u0445\u044d\u043b\u0431\u044d\u0440\u0438\u0439\u043d \u043d\u044d\u0440",voiceLabel:"\u04ae\u0433\u0441\u0438\u0439\u043d \u0445\u044d\u043b\u0431\u044d\u0440"});