/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","ja",{fontSize:{label:"\u30b5\u30a4\u30ba",voiceLabel:"\u30d5\u30a9\u30f3\u30c8\u30b5\u30a4\u30ba",panelTitle:"\u30d5\u30a9\u30f3\u30c8\u30b5\u30a4\u30ba"},label:"\u30d5\u30a9\u30f3\u30c8",panelTitle:"\u30d5\u30a9\u30f3\u30c8",voiceLabel:"\u30d5\u30a9\u30f3\u30c8"});