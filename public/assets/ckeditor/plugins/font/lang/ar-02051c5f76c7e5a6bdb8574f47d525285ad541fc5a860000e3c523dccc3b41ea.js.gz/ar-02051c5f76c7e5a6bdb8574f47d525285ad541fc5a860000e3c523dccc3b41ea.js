/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","ar",{fontSize:{label:"\u062d\u062c\u0645 \u0627\u0644\u062e\u0637",voiceLabel:"\u062d\u062c\u0645 \u0627\u0644\u062e\u0637",panelTitle:"\u062d\u062c\u0645 \u0627\u0644\u062e\u0637"},label:"\u062e\u0637",panelTitle:"\u062d\u062c\u0645 \u0627\u0644\u062e\u0637",voiceLabel:"\u062d\u062c\u0645 \u0627\u0644\u062e\u0637"});