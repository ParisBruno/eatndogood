/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","tt",{fontSize:{label:"\u0417\u0443\u0440\u043b\u044b\u043a",voiceLabel:"\u0428\u0440\u0438\u0444\u0442 \u0437\u0443\u0440\u043b\u044b\u043a\u043b\u0430\u0440\u044b",panelTitle:"\u0428\u0440\u0438\u0444\u0442 \u0437\u0443\u0440\u043b\u044b\u043a\u043b\u0430\u0440\u044b"},label:"\u0428\u0440\u0438\u0444\u0442",panelTitle:"\u0428\u0440\u0438\u0444\u0442 \u0438\u0441\u0435\u043c\u0435",voiceLabel:"\u0428\u0440\u0438\u0444\u0442"});