/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","hr",{fontSize:{label:"Veli\u010dina",voiceLabel:"Veli\u010dina slova",panelTitle:"Veli\u010dina"},label:"Font",panelTitle:"Naziv fonta",voiceLabel:"Font"});