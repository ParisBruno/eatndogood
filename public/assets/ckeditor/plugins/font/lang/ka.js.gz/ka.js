/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","ka",{fontSize:{label:"\u10d6\u10dd\u10db\u10d0",voiceLabel:"\u10e2\u10d4\u10e5\u10e1\u10e2\u10d8\u10e1 \u10d6\u10dd\u10db\u10d0",panelTitle:"\u10e2\u10d4\u10e5\u10e1\u10e2\u10d8\u10e1 \u10d6\u10dd\u10db\u10d0"},label:"\u10e4\u10dd\u10dc\u10e2\u10d8",panelTitle:"\u10e4\u10dd\u10dc\u10e2\u10d8\u10e1 \u10e1\u10d0\u10ee\u10d4\u10da\u10d8",voiceLabel:"\u10e4\u10dd\u10dc\u10e2\u10d8"});