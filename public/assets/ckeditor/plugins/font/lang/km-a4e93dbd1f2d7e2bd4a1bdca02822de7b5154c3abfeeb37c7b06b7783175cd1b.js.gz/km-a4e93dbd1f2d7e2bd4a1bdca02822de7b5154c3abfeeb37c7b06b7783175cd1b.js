/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","km",{fontSize:{label:"\u1791\u17c6\u17a0\u17c6",voiceLabel:"\u1791\u17c6\u17a0\u17c6\u200b\u17a2\u1780\u17d2\u179f\u179a",panelTitle:"\u1791\u17c6\u17a0\u17c6\u200b\u17a2\u1780\u17d2\u179f\u179a"},label:"\u1796\u17bb\u1798\u17d2\u1796\u200b\u17a2\u1780\u17d2\u179f\u179a",panelTitle:"\u1788\u17d2\u1798\u17c4\u17c7\u200b\u1796\u17bb\u1798\u17d2\u1796\u200b\u17a2\u1780\u17d2\u179f\u179a",voiceLabel:"\u1796\u17bb\u1798\u17d2\u1796\u200b\u17a2\u1780\u17d2\u179f\u179a"});