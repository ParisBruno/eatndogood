/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","zh-cn",{fontSize:{label:"\u5927\u5c0f",voiceLabel:"\u6587\u5b57\u5927\u5c0f",panelTitle:"\u5927\u5c0f"},label:"\u5b57\u4f53",panelTitle:"\u5b57\u4f53",voiceLabel:"\u5b57\u4f53"});