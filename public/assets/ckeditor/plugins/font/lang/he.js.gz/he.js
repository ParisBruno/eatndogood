/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","he",{fontSize:{label:"\u05d2\u05d5\u05d3\u05dc",voiceLabel:"\u05d2\u05d5\u05d3\u05dc",panelTitle:"\u05d2\u05d5\u05d3\u05dc"},label:"\u05d2\u05d5\u05e4\u05df",panelTitle:"\u05d2\u05d5\u05e4\u05df",voiceLabel:"\u05d2\u05d5\u05e4\u05df"});