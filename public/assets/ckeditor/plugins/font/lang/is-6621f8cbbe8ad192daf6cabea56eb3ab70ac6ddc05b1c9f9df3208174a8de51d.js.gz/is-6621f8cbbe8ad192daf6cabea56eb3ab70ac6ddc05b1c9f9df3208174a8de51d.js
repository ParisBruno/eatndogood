/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","is",{fontSize:{label:"Leturst\xe6r\xf0 ",voiceLabel:"Font Size",panelTitle:"Leturst\xe6r\xf0 "},label:"Leturger\xf0 ",panelTitle:"Leturger\xf0 ",voiceLabel:"Leturger\xf0 "});