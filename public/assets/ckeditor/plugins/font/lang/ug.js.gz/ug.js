/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","ug",{fontSize:{label:"\u0686\u0648\u06ad\u0644\u06c7\u0642\u0649",voiceLabel:"\u062e\u06d5\u062a \u0686\u0648\u06ad\u0644\u06c7\u0642\u0649",panelTitle:"\u0686\u0648\u06ad\u0644\u06c7\u0642\u0649"},label:"\u062e\u06d5\u062a \u0646\u06c7\u0633\u062e\u0627",panelTitle:"\u062e\u06d5\u062a \u0646\u06c7\u0633\u062e\u0627",voiceLabel:"\u062e\u06d5\u062a \u0646\u06c7\u0633\u062e\u0627"});