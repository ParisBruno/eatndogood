/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","ku",{fontSize:{label:"\u0642\u06d5\u0628\u0627\u0631\u06d5",voiceLabel:"\u0642\u06d5\u0628\u0627\u0631\u06d5\u06cc \u0641\u06c6\u0646\u062a",panelTitle:"\u0642\u06d5\u0628\u0627\u0631\u06d5\u06cc \u0641\u06c6\u0646\u062a"},label:"\u0641\u06c6\u0646\u062a",panelTitle:"\u0646\u0627\u0648\u06cc \u0641\u06c6\u0646\u062a",voiceLabel:"\u0641\u06c6\u0646\u062a"});