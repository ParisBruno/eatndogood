/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","es",{fontSize:{label:"Tama\xf1o",voiceLabel:"Tama\xf1o de fuente",panelTitle:"Tama\xf1o"},label:"Fuente",panelTitle:"Fuente",voiceLabel:"Fuente"});