/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","gu",{fontSize:{label:"\u0aab\u0ac9\u0aa8\u0acd\u0a9f \u0ab8\u0abe\u0a87\u0a9d/\u0a95\u0aa6",voiceLabel:"\u0aab\u0acb\u0aa8\u0acd\u0a9f \u0ab8\u0abe\u0a88\u0a9d",panelTitle:"\u0aab\u0ac9\u0aa8\u0acd\u0a9f \u0ab8\u0abe\u0a87\u0a9d/\u0a95\u0aa6"},label:"\u0aab\u0ac9\u0aa8\u0acd\u0a9f",panelTitle:"\u0aab\u0ac9\u0aa8\u0acd\u0a9f",voiceLabel:"\u0aab\u0acb\u0aa8\u0acd\u0a9f"});