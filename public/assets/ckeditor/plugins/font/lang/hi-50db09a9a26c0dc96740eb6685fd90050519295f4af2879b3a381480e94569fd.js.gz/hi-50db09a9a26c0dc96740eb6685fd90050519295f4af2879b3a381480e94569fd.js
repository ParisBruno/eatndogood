/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","hi",{fontSize:{label:"\u0938\u093e\u0907\u095b",voiceLabel:"Font Size",panelTitle:"\u0938\u093e\u0907\u095b"},label:"\u095e\u0949\u0928\u094d\u091f",panelTitle:"\u095e\u0949\u0928\u094d\u091f",voiceLabel:"\u095e\u0949\u0928\u094d\u091f"});