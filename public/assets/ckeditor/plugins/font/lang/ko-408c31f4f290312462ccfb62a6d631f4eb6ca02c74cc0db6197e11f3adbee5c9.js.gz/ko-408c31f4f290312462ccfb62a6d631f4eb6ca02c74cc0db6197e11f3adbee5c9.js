/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","ko",{fontSize:{label:"\ud06c\uae30",voiceLabel:"\uae00\uc790 \ud06c\uae30",panelTitle:"\uae00\uc790 \ud06c\uae30"},label:"\uae00\uaf34",panelTitle:"\uae00\uaf34",voiceLabel:"\uae00\uaf34"});