/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","vi",{fontSize:{label:"C\u1ee1 ch\u1eef",voiceLabel:"K\xedch c\u1ee1 ph\xf4ng",panelTitle:"C\u1ee1 ch\u1eef"},label:"Ph\xf4ng",panelTitle:"Ph\xf4ng",voiceLabel:"Ph\xf4ng"});