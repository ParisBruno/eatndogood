/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","sr",{fontSize:{label:"\u0412\u0435\u043b\u0438\u0447\u0438\u043d\u0430",voiceLabel:"\u0412\u0435\u043b\u0438\u0447\u0438\u043d\u0430 \u0441\u043b\u043e\u0432\u0430",panelTitle:"\u0412\u0435\u043b\u0438\u0447\u0438\u043d\u0430 \u0441\u043b\u043e\u0432\u0430"},label:"\u0424\u043e\u043d\u0442",panelTitle:"\u041d\u0430\u0437\u0438\u0431 \u0444\u043e\u043d\u0442\u0430",voiceLabel:"\u0424\u043e\u043d\u0442"});