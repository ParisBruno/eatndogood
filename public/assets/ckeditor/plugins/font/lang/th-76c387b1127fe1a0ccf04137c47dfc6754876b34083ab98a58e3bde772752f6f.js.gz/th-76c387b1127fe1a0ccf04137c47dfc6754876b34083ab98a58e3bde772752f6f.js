/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","th",{fontSize:{label:"\u0e02\u0e19\u0e32\u0e14",voiceLabel:"Font Size",panelTitle:"\u0e02\u0e19\u0e32\u0e14"},label:"\u0e41\u0e1a\u0e1a\u0e2d\u0e31\u0e01\u0e29\u0e23",panelTitle:"\u0e41\u0e1a\u0e1a\u0e2d\u0e31\u0e01\u0e29\u0e23",voiceLabel:"\u0e41\u0e1a\u0e1a\u0e2d\u0e31\u0e01\u0e29\u0e23"});