/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","si",{fontSize:{label:"\u0dc0\u0dd2\u0dc1\u0dcf\u0dbd\u0dad\u0dca\u0dc0\u0dba",voiceLabel:"\u0d85\u0d9a\u0dca\u0dc2\u0dbb \u0dc0\u0dd2\u0dc1\u0dcf\u0dbd\u0dad\u0dca\u0dc0\u0dba",panelTitle:"\u0d85\u0d9a\u0dca\u0dc2\u0dbb \u0dc0\u0dd2\u0dc1\u0dcf\u0dbd\u0dad\u0dca\u0dc0\u0dba"},label:"\u0d85\u0d9a\u0dca\u0dc2\u0dbb\u0dba",panelTitle:"\u0d85\u0d9a\u0dca\u0dc2\u0dbb \u0db1\u0dcf\u0db8\u0dba",voiceLabel:"\u0d85\u0d9a\u0dca\u0dc2\u0dbb"});