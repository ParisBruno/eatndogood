/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","hu",{fontSize:{label:"M\xe9ret",voiceLabel:"Bet\u0171m\xe9ret",panelTitle:"M\xe9ret"},label:"Bet\u0171t\xedpus",panelTitle:"Bet\u0171t\xedpus",voiceLabel:"Bet\u0171t\xedpus"});