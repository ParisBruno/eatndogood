/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","oc",{fontSize:{label:"Talha",voiceLabel:"Talha de poli\xe7a",panelTitle:"Talha de poli\xe7a"},label:"Poli\xe7a",panelTitle:"Estil de poli\xe7a",voiceLabel:"Poli\xe7a"});