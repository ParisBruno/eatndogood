/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","bn",{fontSize:{label:"\u09b8\u09be\u0987\u099c",voiceLabel:"Font Size",panelTitle:"\u09b8\u09be\u0987\u099c"},label:"\u09ab\u09a8\u09cd\u099f",panelTitle:"\u09ab\u09a8\u09cd\u099f",voiceLabel:"\u09ab\u09a8\u09cd\u099f"});