/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","no",{fontSize:{label:"St\xf8rrelse",voiceLabel:"Font St\xf8rrelse",panelTitle:"St\xf8rrelse"},label:"Skrift",panelTitle:"Skrift",voiceLabel:"Font"});