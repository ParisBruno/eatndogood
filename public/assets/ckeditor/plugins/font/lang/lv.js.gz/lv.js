/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","lv",{fontSize:{label:"Izm\u0113rs",voiceLabel:"Fonta izme\u0157s",panelTitle:"Izm\u0113rs"},label:"\u0160rifts",panelTitle:"\u0160rifts",voiceLabel:"Fonts"});