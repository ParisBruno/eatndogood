/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","lt",{fontSize:{label:"\u0160rifto dydis",voiceLabel:"\u0160rifto dydis",panelTitle:"\u0160rifto dydis"},label:"\u0160riftas",panelTitle:"\u0160riftas",voiceLabel:"\u0160riftas"});