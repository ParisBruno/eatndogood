/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","fa",{fontSize:{label:"\u0627\u0646\u062f\u0627\u0632\u0647",voiceLabel:"\u0627\u0646\u062f\u0627\u0632\u0647 \u0642\u0644\u0645",panelTitle:"\u0627\u0646\u062f\u0627\u0632\u0647 \u0642\u0644\u0645"},label:"\u0642\u0644\u0645",panelTitle:"\u0646\u0627\u0645 \u0642\u0644\u0645",voiceLabel:"\u0642\u0644\u0645"});