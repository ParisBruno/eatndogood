/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("font","az",{fontSize:{label:"\u015erift \xf6l\xe7\xfcs\xfc",voiceLabel:"\u015erift \xf6l\xe7\xfcs\xfc",panelTitle:"\u015erift \xf6l\xe7\xfcs\xfc"},label:"\u015erift",panelTitle:"\u015erift",voiceLabel:"\u015erift"});