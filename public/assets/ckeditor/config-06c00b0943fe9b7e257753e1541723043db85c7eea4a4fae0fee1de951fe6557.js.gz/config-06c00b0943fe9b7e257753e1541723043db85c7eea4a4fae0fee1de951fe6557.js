CKEDITOR.editorConfig = function (config) {

    config.toolbar = 'Easy';

    config.toolbar_Easy =
    [
        ['Undo','Redo','-','RemoveFormat'],
        ['Styles','Format'],
        ['TextColor'],
        ['Bold','Italic','Underline'], 
        ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
        ['Link','Unlink']
    ];
    config.extraPlugins = 'confighelper,placeholder,';

};



